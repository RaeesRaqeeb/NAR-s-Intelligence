from pymongo import MongoClient
client = MongoClient("mongodb://localhost:27017/")
db = client["university_predictor"]
users = db["users"]
users.insert_one({"email": "test@mongo.com", "password": "123"})
