# === main.py ===
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pymongo import MongoClient
from model_utils import predict
from test_routes import router as test_router

app = FastAPI()

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# MongoDB connection
client = MongoClient("mongodb://localhost:27017")
db = client["university_predictor"]
users_collection = db["users"]
predictions_collection = db["predictions"]
mcqs_collection = db["mcqs"]

@app.post("/register/")
def register_user(data: dict):
    if users_collection.find_one({"email": data["email"]}):
        return {"message": "Email already registered"}
    users_collection.insert_one(data)
    return {"message": "Registered"}

@app.post("/login/")
def login_user(data: dict):
    user = users_collection.find_one(data)
    return {"message": "Login successful" if user else "Invalid credentials"}

@app.post("/predict/")
def predict_endpoint(data: dict):
    result = predict(data)
    data["prediction"] = result
    predictions_collection.insert_one(data)
    return result

@app.get("/get_prediction/{email}")
def get_prediction(email: str):
    result = predictions_collection.find_one({"email": email}, {"_id": 0})
    return result if result else {"message": "No prediction found"}

@app.get("/get_mcqs/{subject}")
def get_mcqs(subject: str):
    questions = list(mcqs_collection.find({"subject": subject}, {"_id": 0}))
    return questions[:5]  # Send 5 for preview/testing

# Mount test system routes
app.include_router(test_router)
