# === Updated test_routes.py ===
from fastapi import APIRouter, Request
from pydantic import BaseModel
from typing import List, Dict
from pymongo import MongoClient
from model_utils import predict  # Include the prediction model

router = APIRouter()

client = MongoClient("mongodb://localhost:27017")
db = client["university_predictor"]
mcqs_collection = db["mcqs"]
tests_collection = db["tests"]
predictions_collection = db["predictions"]

class TestSubmission(BaseModel):
    email: str
    answers: Dict[str, List[str]]
    times: Dict[str, int]
    preferred_field: str
    region_preference: str
    university_choices: List[str]

@router.get("/get_question/{subject}/{index}")
def get_question(subject: str, index: int):
    question = mcqs_collection.find({"subject": subject}).skip(index).limit(1)
    q = next(question, None)
    if not q:
        return {"question": None}
    return {
        "id": str(q.get("_id")),
        "subject": q["subject"],
        "question": q["question"],
        "options": q["options"]
    }

@router.post("/submit_test")
async def submit_test(request: Request):
    body = await request.json()
    print("📩 RAW SUBMISSION BODY:", body)

    try:
        submission = TestSubmission(**body)
    except Exception as e:
        print("❌ Validation failed:", e)
        return {"error": "Invalid format", "details": str(e)}

    scores = {}
    total = 0
    print("📥 SUBMISSION:", submission.answers)

    for subject, given_answers in submission.answers.items():
        actual_questions = list(mcqs_collection.find({"subject": subject}))
        correct = 0

        for idx, user_ans in enumerate(given_answers):
            if idx < len(actual_questions):
                correct_index = actual_questions[idx].get("answer")  # e.g., "2"
                print(f"Q{idx+1}: Your Answer = {user_ans}, Correct = {correct_index}")
                if user_ans == correct_index:
                    correct += 1

        scores[subject] = correct
        print(f"✅ Subject: {subject}, Correct Answers: {correct}")
        total += submission.times[subject]

    # Store test result
    tests_collection.insert_one({
        "email": submission.email,
        "answers": submission.answers,
        "times": submission.times,
        "scores": scores,
        "total_time": total
    })

    # Send to prediction model
    prediction_input = {
        "email": submission.email,
        "physics_marks": scores.get("Physics", 0) * 10,
        "math_marks": scores.get("Math", 0) * 10,
        "english_marks": scores.get("English", 0) * 10,
        "time_physics_pct": submission.times.get("Physics", 0) / 300,
        "time_math_pct": submission.times.get("Math", 0) / 300,
        "time_english_pct": submission.times.get("English", 0) / 300,
        "number_of_attempts": 1,
        "preferred_field": submission.preferred_field,
        "region_preference": submission.region_preference,
        "university_choices": submission.university_choices
    }

    result = predict(prediction_input)
    prediction_input["prediction"] = result
    db["predictions"].insert_one(prediction_input)

    return {
        "message": "Test submitted + prediction stored",
        "scores": scores,
        "total_time": total,
        "prediction": result
    }
