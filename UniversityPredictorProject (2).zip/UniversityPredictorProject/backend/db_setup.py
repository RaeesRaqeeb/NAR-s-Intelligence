# MongoDB seeder script

from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017/")
db = client["university_predictor"]
mcqs = db["mcqs"]

mcqs.delete_many({})

sections = {
    "Math": 100,
    "Physics": 60,
    "English": 40
}

for subject, count in sections.items():
    for i in range(1, count + 1):
        mcqs.insert_one({
            "section": subject,
            "question": f"What is the answer to {subject} Q{i}?",
            "options": {
                "A": f"{subject} A{i}",
                "B": f"{subject} B{i}",
                "C": f"{subject} C{i}",
                "D": f"{subject} D{i}"
            },
            "answer": "A"
        })

print("✅ MCQs seeded into MongoDB!")
