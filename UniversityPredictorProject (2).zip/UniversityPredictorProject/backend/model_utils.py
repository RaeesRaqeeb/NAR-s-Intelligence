# Model utility functions

import joblib
import numpy as np
import pandas as pd

pipe1 = joblib.load("stage1_pipeline.pkl")
pipe2 = joblib.load("stage2_pipeline.pkl")

def generate_time_pct():
        return float(np.clip(np.random.normal(1.0, 0.1), 0.4, 1.0))
universities = {
        'FAST':    {'difficulty': 7, 'fields': ['CS']},
        'NUST':    {'difficulty': 8, 'fields': ['CS', 'Engineering', 'Medicine']},
        'UET':     {'difficulty': 6, 'fields': ['Engineering']},
        'COMSAT':  {'difficulty': 5, 'fields': ['CS', 'Business']},
        'GIKI':    {'difficulty': 9, 'fields': ['Engineering', 'CS']}
    }
def engineer(df):
    df['average_marks'] = (df['physics_marks'] + df['math_marks'] + df['english_marks']) / 3
    
        # Feature engineering
    for univ, idx in universities.items():
            df[f'perf_gap_{univ}'] = df['average_marks'] - 50 * idx['difficulty']
    df['phy_norm'] = df['physics_marks'] / 60
    df['math_norm'] = df['math_marks'] / 100
    df['eng_norm'] = df['english_marks'] / 40

    def pad_choices(choices):
        choices = list(choices)
        while len(choices) < 3:
            choices.append(choices[-1])
        return choices[:3]
    df['time_physics_pct'] = generate_time_pct()
    df['time_math_pct'] = generate_time_pct()
    df['time_english_pct'] =generate_time_pct()
    df['number_of_attempts'] = df['number_of_attempts'].fillna(1)
    df[['choice1','choice2','choice3']] = pd.DataFrame(df['university_choices'].apply(pad_choices).tolist(), index=df.index)
    df['eff_phy'] = df['time_physics_pct'] * df['phy_norm']
    df['eff_math'] = df['time_math_pct'] * df['math_norm']
    df['eff_eng'] = df['time_english_pct'] * df['eng_norm']
    df['university_difficulty_index'] = df['university_choices'].map(lambda x: universities[x]['difficulty'])
    df['attempt_x_diff'] = df['number_of_attempts'] * df['university_difficulty_index'].fillna(1)
    return df

def predict(data_dict):
    allowed_unis = ["FAST", "NUST", "GIKI", "UET", "COMSAT"]
    data_dict['university_choices'] = [u if u in allowed_unis else allowed_unis[0] for u in data_dict.get('university_choices', [])]
    print("🔍 Input data:", data_dict['university_choices'])
    df = pd.DataFrame(data_dict)
    df = engineer(df)
    # print(df.columns)
    numeric_feats = ['average_marks','phy_norm','math_norm','eng_norm','time_physics_pct',
                 'time_math_pct','time_english_pct','number_of_attempts','attempt_x_diff'] + \
                [f'perf_gap_{u}' for u in ['FAST','NUST','GIKI','UET','COMSAT']]
    categorical_feats = ['preferred_field','region_preference','choice1','choice2','choice3']
    # print(df[numeric_feats+categorical_feats].columns)
    Prediction_input = df[numeric_feats+categorical_feats].copy()
    print(Prediction_input.columns)
    adm = pipe1.predict(Prediction_input)[0]
    print("🔍 Admission status prediction:", adm)
    uni = "None"
    if adm == 1:
        uni = pipe2.predict(df)[0]
        
    print("🔍 Prediction result:", uni)

    return {"admission_status": int(adm), "university": uni}
