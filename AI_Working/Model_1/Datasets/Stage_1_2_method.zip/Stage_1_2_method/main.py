from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
import joblib
import pandas as pd
from pydantic import BaseModel
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
import joblib
import pandas as pd

app = FastAPI()
templates = Jinja2Templates(directory="templates")

# Load models
admission_model = joblib.load("stage1_pipeline.pkl")
university_model = joblib.load("stage2_pipeline.pkl")

@app.get("/", response_class=HTMLResponse)
async def form_get(request: Request):
    return templates.TemplateResponse("form.html", {"request": request})

@app.post("/predict/", response_class=HTMLResponse)
async def predict(
    request: Request,
    physics_marks: float = Form(...),
    math_marks: float = Form(...),
    english_marks: float = Form(...),
    time_physics_pct: float = Form(...),
    time_math_pct: float = Form(...),
    time_english_pct: float = Form(...),
    number_of_attempts: int = Form(...),
    preferred_field: str = Form(...),
    region_preference: str = Form(...),
    choice1: str = Form(...),
    choice2: str = Form(...),
    choice3: str = Form(...)
):
    # Create DataFrame
    df = pd.DataFrame([{
        "physics_marks": physics_marks,
        "math_marks": math_marks,
        "english_marks": english_marks,
        "time_physics_pct": time_physics_pct,
        "time_math_pct": time_math_pct,
        "time_english_pct": time_english_pct,
        "number_of_attempts": number_of_attempts,
        "preferred_field": preferred_field,
        "region_preference": region_preference,
        "choice1": choice1,
        "choice2": choice2,
        "choice3": choice3
    }])

    # Feature engineering
    df['average_marks'] = (physics_marks + math_marks + english_marks) / 3
    for uni in ['FAST', 'NUST', 'GIKI', 'COMSAT', 'UET']:
        df[f'perf_gap_{uni}'] = df['average_marks'] - (60 + 5 * ['FAST', 'NUST', 'GIKI', 'COMSAT', 'UET'].index(uni))

    df['phy_norm'] = physics_marks / 100
    df['math_norm'] = math_marks / 100
    df['eng_norm'] = english_marks / 100
    df['attempt_x_diff'] = number_of_attempts * (math_marks - physics_marks)

    # Predict admission
    admitted = admission_model.predict(df)[0]
    result = {"admitted": bool(admitted)}

    if admitted:
        recommended_uni = university_model.predict(df)[0]
        result["recommended_university"] = recommended_uni
    else:
        result["recommended_university"] = "Need Improvement"

    return templates.TemplateResponse("result.html", {
        "request": request,
        "admitted": result["admitted"],
        "university": result["recommended_university"]
    })
